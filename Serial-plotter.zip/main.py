from ncce.mitdb_data import load, plot
heartbeat_data = load(123)
print(heartbeat_data)
plot(heartbeat_data, 'heartbeats.png')